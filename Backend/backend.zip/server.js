const Express = require('express');
// const { createServer } = require("http");
const mysql = require('mysql');
const cors = require('cors');
// const { Server } = require("socket.io");
require('dotenv').config();

const port = process.env.PORT;

const app = Express();
// Middleware
app.use(cors());
app.use(Express.json({ limit: '50mb' }));
app.use(Express.urlencoded({ limit: '50mb', extended: true }));
//mysql connect
const db = mysql.createConnection({
    host: process.env.DEV_HOST,//process.env.DB_HOST,
    user: process.env.DEV_U_NAME,//process.env.DB_USER_NAME,
    password: process.env.DEV_PASSWORD,//process.env.DB_PASSWORD,
    database: process.env.DEV_DB_NAME,//process.env.DB_NAME
    dateStrings: true,

});
// connect to database
db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Connected to database');
});
global.db = db;

const user = require('./routes/user');
const items = require('./routes/items');
const orders = require('./routes/orders');
const dashboard = require('./routes/dashboard');
const catagories = require('./routes/catagoryes');
const customers = require('./routes/customers');

app.use('/api/user', user);
app.use('/api/items', items);
app.use('/api/orders', orders);
app.use('/api/dashboard', dashboard);
app.use('/api/catagories', catagories);
app.use('/api/customers', customers);

//start node js server and socket io together
// const httpServer = createServer(app);
// const io = new Server(httpServer, {cors: {origin: "http://ceylontearepo.com"}});

// global.io = io

// io.on("connection", (socket) => {
//     console.log("socket io server started" + socket.id);
// });

// httpServer.listen(port);

app.listen(port, () => {
    console.log("server started");
});