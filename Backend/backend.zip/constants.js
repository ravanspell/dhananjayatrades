module.exports ={
    USER: 'user',
    ADMIN : 'admin',
    SUPER_ADMIN: 'superadmin',
}